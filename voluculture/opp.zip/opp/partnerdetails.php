<?php
/*
Template Name: Partnerdetails
*/ 
get_header();

echo '
   <link rel="stylesheet" href="css/display.css">

      <div class="bar1" style ="background-image: url('."http://localhost/voluculture/wp-content/themes/goodwish/img/mchele.jpg".')">
    <h1 style="color: #ffffff;text-align:center;">
    <span>Our Partners</span>
    </h1>
  </div>
  <div style="height: 30px;">
    
  </div>

  <div class="partnerimage1">
  <div class="stat_image">
  <img src="'.get_template_directory_uri().'/img/image1.jpg" id="img1"> 
  <div>
  <div class ="logo">
   <img src="'.get_template_directory_uri().'/img/SOMO.png" id="img2">
 </div>
   
    </div>

    
    
  </div>

  
<section class="class7">
  <div class="container pt-5 pb-2">

    <div class="row mx-auto">
        <div class="col-md-10 card pl-0 pr-0 mb-4">
                <table class="table3">
                    <thead class="thead-light text-secondary">
                        <tr>
                            <th scope="col" style="width: 30%">Website URL</th>
                            <th scope="col" style="width: 20%">Location</th>
                            <th scope="col" style="width: 20%">Email Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Website URL </td>
                            <td>Nairobi Kenya</td>
                            <td>somo@gmail.com</td>
                       
                        </tr>

                     
                    </tbody>
                </table>
        </div>
       
      </div>


      </div>


      </div>
  </section>


  <section class="class8">
  <div class="container pt-5 pb-2">

    <div class="row mx-auto">
        <div class="col-md-10 card pl-0 pr-0 mb-4">
                <table class="table2">
                    <thead class="thead-light text-secondary">
                        <tr>
                            <th scope="col" style="width: 30%">Year Founded</th>
                            <th scope="col" style="width: 20%">Telephone</th>
                            <th scope="col" style="width: 20%">Postal Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>2010</td>
                            <td>+254721654908</td>
                            <td>Nairobi,Kenya</td>
                       
                        </tr>

                     
                    </tbody>
                </table>
        </div>
       
      </div>


      </div>


      </div>
  </section>

  <section class="class9">
  <div class="container pt-5 pb-2">

    <div class="row mx-auto">
        <div class="col-md-10 card pl-0 pr-0 mb-4">
                <table class="table1" style="width:100%;">
                    <thead class="thead-light text-secondary">
                        <tr>
                            <th scope="col" style="width: 30%">What we do</th>
                            <th scope="col" style="width: 20%">Who we are</th>
                            <th scope="col" style="width: 20%">Our vision/Mission</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>   As change agents, we will achieve our vision through an intentional and purposeful approach that will incorporate the following: tri-annual camps, access to quality early childhood care, education, and life skills development training, as well as mentor-ship programs that work to promote equal opportunities for poor and vulnerable children. </td>

                            <td>DCI aims to create a haven for children, one where they can discover and enhance their talents and gifts. We want to provide all children with the opportunity to contribute their unique visions and abilities towards improving their communities – and their own lives. </td>

                            <td>To positively transform the lives of children from impoverished communities by upholding their dignity through holistic child development programs.. </td>
                       
                        </tr>
                     

                     
                    </tbody>
                </table>
        </div>
       
      </div>


      </div>


      </div>
  </section>

';

?>







<?php
/*
Template Name: Opportunitylayout
*/ 
get_header();

echo '
    <link rel="stylesheet" href="css/display.css">
 

  <div class="bar1" style ="background-image: url('."http://localhost/voluculture/wp-content/themes/goodwish/img/mchele.jpg".')">
    <h2 style="color: #ffffff;text-align:center;">
    <span>Opportunities</span>
    </h2>
  </div>

  <div style ="height:30px">
  </div>

  <section class="class1" >

 <div class="container">

  <div class="container1">

    <div class="projectimage">
   <img src="'.get_template_directory_uri().'/img/image1.jpg" style="width:100%;height:200px;">
    </div>
    </div>

    <div class="projectname"href="opportunitydetails.html" >
    <h3> Become A Fellow</h3>
    </div>


   
    <div class="Orgname">
    <h3>Somo</h3>
    </div>

    <div class="orgdescription">
    <p>Somo</p>
    </div>

   

  



 <a href=" http://localhost/voluculture/?page_id=1217" ><button type="button" class="btn" style="width: 50%;color:#ffffff;">Volunteer</button></a>
</div> 
 



  

</section>



';

?>





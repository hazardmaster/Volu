<?php
/*
Template Name: partnerlayout
*/ 
get_header();

echo '
   <link rel="stylesheet" href="css/display.css">

    <div class="bar1" style ="background-image: url('."http://localhost/voluculture/wp-content/themes/goodwish/img/mchele.jpg".')">
    </div>

        <div class="part" >
      
        <div class="partnerimage1">
        <img src="'.get_template_directory_uri().'/img/mcmillan.jpg">
        </div>
        <div class="logo1">
            <a href=" http://localhost/voluculture/?page_id=1225"><img id="partlogo" src="'.get_template_directory_uri().'/img/SOMO.png"></a>
             </div>
            <div class="partnername">
            <p>Somo</p>
           </div>
       
    </div>

 


 



  













';

?>





<?php
/*
Template Name: Eventlayout
*/ 
get_header();

echo '

    <link rel="stylesheet" href="css/display.css">
  

    <div class="bar1" style ="background-image: url('."http://localhost/voluculture/wp-content/themes/goodwish/img/mchele.jpg".')">
    <h1 style="color: #ffffff;text-align:center;">
    <span>Events</span>
    </h1>
  </div>

  <section class="class3" >


  <div class="container1">

    <div>
   <img src="'.get_template_directory_uri().'/img/mcmillan.jpg" id="eventimage1">
   
    </div>
    </div>

    <div >
    <a id="eventlink" href=" http://localhost/voluculture/?page_id=1221"><h3 id="eventname">Film Screenings</h3></a>
    </div>


   
    <div class="eventtime">
    <p>6:00am - 6:00pm</p>
    </div>

    <div class="eventdescription">
    <p>Kaloleni,Madaraka and Mcmillan Memorial Library Nairobi CBD</p>
    </div>

   

  



 <a href=" http://localhost/voluculture/?page_id=1221" ><button type="button" class="btn" style="width: 50%;color:#ffffff;">Read More</button></a>

 



  

</section>










';

?>





<?php
/*
Template Name: Opportunitydescription
*/ 
get_header();

echo
'

	 <link rel="stylesheet" href="css/display.css">
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<div class="bar1" style ="background-image: url('."http://localhost/voluculture/wp-content/themes/goodwish/img/mchele.jpg".')">
		
    <h1 style="color: #ffffff;text-align:center;">
    <span>Become A fellow</span>
    </h1>
  </div>
  <div style="height:30px;"></div>
   <div class="topnav">
  	 <input type="text" placeholder="Type here..">
  	 <div class="search-container">
  	 <button type="submit"><i class="fa fa-search"></i></button>
  	 </div>
  </div>



  <div class="bar2">
   <img src="'.get_template_directory_uri().'/img/image1.jpg" style="width:50%;height:20%;">
  </div>


  	<div>
    <h3 style="color: #000000;text-align:center;">
    <span>Become A fellow</span>
    </h3>
    <p style="width: 70%;text-indent: 50px;">We believe the potential and talent that exists in low income areas.Do you have a socially focused business idea and want to start your business?</p>
  </div>
  <div style="height: 30px;">
  	
  </div>
 

   <!-- The sidebar -->
<div class="nav">
  <div>
   <img src="'.get_template_directory_uri().'/img/image1.jpg" id="oppimage">
    <p>Become an entepreneur</p>
   <div >
  
   <p>August 13 2019</p>

   </div>
   </div>


</div>

<div class="content">

<div>
	<ul>
<li>
Best  for	
</li>		
	</ul>
	<p>Individuals</p>


</div>
<div>
	<ul>
<li>
Skills Needed	
</li>		
	</ul>
	<p>None</p>


</div>

<div>
	<ul>
<li>
When	
</li>		
	</ul>
	<p>12 weeks repeats monthly</p>


</div>

<div>
	<ul>
<li>
Where	
</li>		
	</ul>
	<p>On site</p>


</div>
</div>


 

  	<div>
    <h2 style="color: #000000;text-align:center;">
    <span>Post A Comment</span>
    </h2>

    <textarea class="textarea"rows="10" cols="50">
    	
    </textarea>
 
  </div>

<button class="apply"style="color:#ffffff;">Apply Now </button><!-- jQuery 1.7.2+ or Zepto.js 1.0+ -->





';

?>





